import java.util.HashMap;
import java.io.IOException;
import java.io.BufferedReader;
import java.util.Set;
import java.util.HashSet;
import java.util.Map;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.File;
import org.jsoup.Jsoup;
import org.jsoup.select.Elements;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class SolrEdgeList_BostonGlobe {
	
	public static void main(String[] args) throws IOException {
		try {
			String nextLine="";
			BufferedReader br = new BufferedReader(new FileReader("C:/Users/Mounika PSL/Downloads/BG/BG/Boston Global Map.csv"));
			Map<String, String> File_To_URL = new HashMap<String,String>();
	        Map<String, String> URL_To_File = new HashMap<String,String>();
			while((nextLine=br.readLine())!=null)
				
			{
				String[] row=nextLine.split(",");
				File_To_URL.put(row[0], row[1]);
				URL_To_File.put(row[1], row[0]);
				
				
			}
			
			System.out.println("Maps are prepared");
			System.out.println("File_To_URL size: "+File_To_URL.size());
			System.out.println("URL_To_File size: "+URL_To_File.size());
			
			File directoryList=new File("C:/Users/Mounika PSL/Downloads/BG/BG/BG");
			Set<String> edgesSet = new HashSet<String>();
			int count=0;
			for(File file: directoryList.listFiles()) {
				Document doc = Jsoup.parse(file , "UTF-8" , File_To_URL.get(file.getName()));
	        	Elements links = doc.select("a[href]");
	        	Elements pages=doc.select("[src]");
	        	for(Element link: links) {
	        		
	        		String url = link.attr("abs:href").trim();
	        		
	        		if(URL_To_File.containsKey(url)) {
	        			edgesSet.add(file.getName() + " " + URL_To_File.get(url));
	        			
	        			System.out.println("working on it... "+count);
	        			count++;
	        			
	        		}
				
			}
			
			
		}
			PrintWriter out = new PrintWriter("edgeList_1_04.txt") ;
			for (String s:edgesSet)
			{
				out.println(s);
			}
			System.out.println("Done Creating edgeList.txt !");
		}
		catch(Exception e)
		{
			System.out.println("Exception"+e);
		}
	}

}
